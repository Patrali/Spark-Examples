package examples

import org.apache.spark.{SparkConf, SparkContext}
import org.apache.hadoop.io.{LongWritable, Text}
import org.apache.hadoop.mapred.TextInputFormat

/**
  * Created by pbose on 3/8/2018.
  *
  * Play with threads why +1?
  * internally calls hadoop api and then strips off map output
  */
object PartitionExample {

  def main(args: Array[String]) {

    val sc = new SparkContext(new SparkConf().setMaster("local").setAppName("partition example"))

    //actual textFile api converts to the following code
    val dataRDD = sc.hadoopFile(args(0), classOf[TextInputFormat], classOf[LongWritable], classOf[Text],
      sc.defaultMinPartitions).map(pair => pair._2.toString)



    println("Total partitions used : " + dataRDD.partitions.length)

  }

}
