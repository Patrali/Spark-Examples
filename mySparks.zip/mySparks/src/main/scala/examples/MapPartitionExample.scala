package examples

import org.apache.spark.SparkContext

/**
  * Created by pbose on 3/8/2018.
  * set HADOOP_HOME
  * pass params local[2] C:\patrali_sand\44_sprint\1425_Shawn\hadoop\mySparks\src\main\resources
  *
  * we want to find out min and max of an RDD at the same time.
  * If we do it row by row , it will go over the data multiple times.

  *So the logic is :
  *  we will find out min and max first and then find out min and max accross the partitions
  *  -> need all the rows at the same time
  *  -> mapPArtitions returns iterator
  *  -> because it is not going to load all the data in the memory but it will load
  *  more data in the memory when asked
  *  -> fold operation means reduction ( take some data and bring it into single value)

  * example:
  *   say we had a list of Ints 1, 2, and 3.
  *   We could call foldLeft(“X”)((b,a) => b + a). For the first item, 1,
  *   the function we define would add string “X” to Int 1, returning string “X1″.
  *   For the second list item, 2, the function would add string “X1″ to Int 2, returning “X12″.
  *   And for the final list item, 3, the function would add “X12″ to 3 and return “X123″.

  */

object MapPartitionExample
{

  def main(args: Array[String]) {

    val sc = new SparkContext(args(0),"map partition example")
    val salesData = sc.textFile(args(1))

    val (min,max)=salesData.mapPartitions(iterator => {
      val (min,max) = iterator.foldLeft((Double.MaxValue,Double.MinValue))((acc,salesRecord) => {
        val itemValue = salesRecord.split(",")(3).toDouble
        (acc._1 min itemValue , acc._2 max itemValue)
      })
      List((min,max)).iterator
    }).reduce((a,b)=> (a._1 min b._1 , a._2 max b._2))
    println("min = "+min + " max ="+max)

  }

}
